function ispis(naslov,opis){
	document.getElementById('divRez').innerHTML = '<h2 class="testKlasa">'+naslov+'</h2><p>'+opis+'</p>';
}